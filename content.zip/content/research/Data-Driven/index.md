---
title: Data-Driven Discovery of Materials
summary: 
weight: 30
tags:
  - DDD
#date: 2022-01-01
#external_link: http://github.com
design:
  view: 1
  columns: '1'
---
Data-driven Approach to Explore Materials