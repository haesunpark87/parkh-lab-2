---
title: Don Geon joined as undergraduate researcher!
date: 2024-08-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Don Geon joined as undergraduate researcher. Welcome!

<!--more-->
