---
title: HyoungJoon and Wonwoo joined the group!
date: 2025-01-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

HyoungJoon and Wonwoo have joined the group as a graduate student 🎓 and an undergraduate researcher 🔬, respectively. Welcome! 🎉


<!--more-->
