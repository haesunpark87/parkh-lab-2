---
title: Haesun gave a talk at AMSM 2024
date: 2024-10-28
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at AMSM 2024 conference on “Layered Materials for Multivalent Cation Intercalation Electrodes: A Systematic First-Principles Evaluation”


<!--more-->
