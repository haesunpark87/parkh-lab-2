---
title: Haesun gave a talk at KIST
date: 2023-07-04
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at KIST on "In Silico Design of Emerging Energy Storage/Conversion Materials."
 
<!--more-->
