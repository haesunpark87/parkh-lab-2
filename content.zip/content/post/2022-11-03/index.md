---
title: Haesun gave a talk at the 2022 Fall KECS
date: 2022-11-04
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the 2022 Fall Meeting of the Korean Electrochemical Society!
<!--more-->
