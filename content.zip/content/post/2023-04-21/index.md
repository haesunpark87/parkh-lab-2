---
title: Haesun gave a talk at the 2023 KSME conference!
date: 2023-04-21
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the 2023 KSME Thermal Engineering Division Conference

<!--more-->
