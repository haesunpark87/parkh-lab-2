---
title: Haesun gave a talk at the 2024 KECS Fall meeting
date: 2024-04-04
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the 2024 KECS Fall meeting on "Exploring Battery Materials: Can First-Principles Calculations Unlock New Realms?"
 
<!--more-->
