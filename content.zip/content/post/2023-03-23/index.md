---
title: Haesun gave a talk at Kyunghee University
date: 2023-03-23
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave a talk at the department of Mechnical Engineering of Kyunghee University on "Investigation of Energy Materials with Atomistic Modeling:Ca-ion Batteries, Solid Electrolyte, and MXene"
<!--more-->
