---
title: Haesun gave a talk at POSTECH
date: 2024-07-05
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the department of Materials Science and Engieering of POSTECH on "Exploring Battery Materials: Can First-Principles Calculations Unlock New Realms?"
 
<!--more-->
