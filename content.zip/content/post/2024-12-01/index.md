---
title: Sanghyeon joined the group!
date: 2024-11-27
#external_link: http://github.com
image:
  focal_point: 'top'
---

Sanghyeon joined the group as an undergraduate 🎓 researcher🔬. Welcome! 🎉


<!--more-->
