---
title: Haesun gave a talk at the KSME 2024 Spring meeeting on CAE and Applied Mechanics Division
date: 2024-05-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the KSME 2024 Spring meeeting on CAE and Applied Mechanics Division on "Active Learning Framework for Expediting the Search of Thermodynamically Stable MXenes in the Extensive Chemical Space"
 
<!--more-->
