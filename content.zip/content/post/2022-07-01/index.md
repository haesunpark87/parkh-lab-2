---
title: Ho Seok and Myeong Jun joined as undergraduate researchers!
date: 2022-07-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Ho Seok and Myeong Jun joined as undergraduate researchers. Welcome! 
<!--more-->
