---
title: Hyobin joined the group!
date: 2025-03-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Hyobin has joined the group as an undergraduate researcher 🔬. Welcome! 🎉


<!--more-->
