---
title: Haesun gave a talk at the 2023 MRS Korea Fall conference
date: 2023-11-16
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the "Rechargeable batteries: From materials to cell development" special symposium of 2023 MRS Korea Fall conference 
 
<!--more-->
