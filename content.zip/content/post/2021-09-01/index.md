---
title: MIDAS Lab launched!
date: 2021-09-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun accepts an assistant professor position at the School of Intergrative Engineering at Chung-Ang University, and launches a laboratory for _MaterIals Design for Advanced energy Solutions_. 
<!--more-->
