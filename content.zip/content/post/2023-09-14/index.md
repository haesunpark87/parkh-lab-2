---
title: Calculation nodes arrived!
date: 2023-09-14
#external_link: http://github.com
image:
  focal_point: 'top'
---

Nodes (1 master node, 1 GPU node, and 5 CPU nodes) for DFT calculation have finally arrived. 

<!--more-->
