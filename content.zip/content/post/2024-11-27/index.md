---
title: Haesun gave a talk at KETI
date: 2024-11-27
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at Korea Electronics Technology Institute (KETI)  on “First-principles Studies on Sulfide Solid Electrolyte”


<!--more-->
