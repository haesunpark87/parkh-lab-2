---
title: Daehyun joined as a master student!
date: 2023-02-20
#external_link: http://github.com
image:
  focal_point: 'top'
---

Daehyun joined our group as a master student. Welcome!

<!--more-->
