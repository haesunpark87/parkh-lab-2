---
title: Haesun gave a talk at Inha University
date: 2023-01-19
#external_link: http://github.com
image:
  focal_point: 'top'
---

Haesun gave an invited talk at the department of Mechanical Engineering of Inha University on "Exploring Battery Materials: Can First-Principles Calculations Unlock New Realms?"
 
<!--more-->
