---
title: Grant from National Research Foundation!
date: 2022-03-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

We receive a research grant from _National Research Foundation_ for the Young Researcher Program. 
<!--more-->
