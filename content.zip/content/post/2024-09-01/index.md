---
title: JongHun and Mansang joined as graduate students!
date: 2024-09-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

JongHun and Mansang joined as graduate students. Welcome!

<!--more-->
