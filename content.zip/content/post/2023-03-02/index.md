---
title: JongHun and Minsoo joined as undergraduate researchers!
date: 2023-03-02
#external_link: http://github.com
image:
  focal_point: 'top'
---

JongHun and Minsoo joined our group as undergraduate researchers. Welcome!

<!--more-->
