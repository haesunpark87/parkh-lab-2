---
title: Hyesu joined as an undergraduate researcher!
date: 2022-08-01
#external_link: http://github.com
image:
  focal_point: 'top'
---

Hyesu joined as an undergraduate researcher. Welcome! 
<!--more-->
