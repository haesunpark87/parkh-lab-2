---
title: MIDAS group attended 2023 Spring KECS
date: 2023-04-07
#external_link: http://github.com
image:
  focal_point: 'top'
---

MIDAS group attended 2023 Spring KECS.
Haesun gave a talk regarding charge transfer phenomena at the Li/SE interface. 
Myeong Jun and Hyesu gave a poster presentation

<!--more-->
