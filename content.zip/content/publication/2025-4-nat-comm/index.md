---
title: 'Silver exsolution from Li-argyrodite electrolytes for anode-less all-solid-state batteries'
authors:
  - Seung Ho Choi
  - Chang Hoon Baek
  - Jihoon Oh
  - Geung-Jong Lee
  - Minsoo Kim
  - Hyesu Lee
  - Dong-Joo Yoo
  - Yoon Seok Jung
  - KyungSu Kim
  - Ji-Sang Yu
  - Woosuk Cho
  - Haesun Park
  - Jang Wook Choi
author_notes:
  - Corresponding Author, Equal contribution
  - Equal contribution
  - 
  - 
  - 
  - 
  - 
  - 
  - 
  - 
  - Corresponding Author
  - Corresponding Author
  - Corresponding Author


date: '2025-07-01'
doi: '10.1038/s41467-025-61074-9'
publication_types: ['2']
publication: '*Nature Communications*, 16, 1-9, (2025)'
abstract: 

url_pdf: 'publications/2025-2-nat-comm.pdf'

---


<!--- Supplementary notes can be added here, including [code and math](https://wowchemy.com/docs/content/writing-markdown-latex/). --->