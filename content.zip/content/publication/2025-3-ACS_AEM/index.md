---
title: 'Multivalent Ion Mobility in Layered NbS2 and NbSe2 Structures with Trigonal Prismatic Transition Metal Coordination'
authors:
  - Daehyun Kim
  - Haesun Park
author_notes:
  - 
  - Corresponding Author


date: '2025-05-19'
doi: '10.1021/acsaem.5c00560'
publication_types: ['2']
publication: '*ACS Applied Energy Materials*, 8, 11, 7217-7225 (2025)'
abstract: 

url_pdf: 'publications/2025-3-ACS-AEM.pdf'

---


<!--- Supplementary notes can be added here, including [code and math](https://wowchemy.com/docs/content/writing-markdown-latex/). --->