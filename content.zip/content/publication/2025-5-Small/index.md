---
title: 'Tuning Interface Dynamics of Benzene-based Molecular Dipoles for High Capacity and Long Lifespan in Lithium Metal Batteries'
authors:
  - Chae Yeong Son
  - Daehyun Kim
  - Haesun Park
  - Won-Hee Ryu
author_notes:
  - Equal Contribution 
  - Equal Contribution 
  - Corresponding Author
  - Corresponding Author


date: '2025-08-03'
doi: ''
publication_types: ['2']
publication: '*Small*, Accepted (2025)'
abstract: 

url_pdf: 'publications/'

---


<!--- Supplementary notes can be added here, including [code and math](https://wowchemy.com/docs/content/writing-markdown-latex/). --->