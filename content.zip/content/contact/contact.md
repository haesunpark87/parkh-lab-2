---
content:
  address:
    city: Seoul
    country: Republic of Korea
    country_code: ROK
    postcode: "06974"
    region: Seoul
    street: 84 Heukseok-ro
#  appointment_url: https://calendly.com
  autolink: true
  coordinates:
    latitude: "37.5036"
    longitude: "126.9571"
  directions: Enter Building 208 and take the elevator to Office 527-1 on Floor 5
  email: parkh@cau.ac.kr
#  form:
#    formspree:
#      id: null
#    netlify:
#      captcha: false
#    provider: netlify
#  office_hours:
#  - Monday 10:00 to 13:00
#  - Wednesday 09:00 to 10:00
  phone: +02 (2) 820-5231
design:
  columns: "1"
headless: true
subtitle: Feel free to contact me if you are interested in our research or collaboration with us!
title: Contact
weight: 10
widget: contact
---

