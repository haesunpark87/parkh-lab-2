---
advanced:
  css_class: fullscreen
design:
  background:
    image: blue_dragon.jpg
    image_darken: 0
    image_parallax: false
    image_position: center
    image_size: cover
    text_color_light: true
  columns: "1"
  spacing:
    padding:
    - 50px
    - "50"
    - 50px
    - "50"
headless: true
subtitle: null
title: null
weight: 20
widget: blank
---
