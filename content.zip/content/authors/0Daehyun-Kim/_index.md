---
education:
  courses:
  - course: PhD in Integrative Engineering
    institution: Chung-Ang University
    year: 2025.03~
  - course: MS in Integrative Engineering
    institution: Chung-Ang University
    year: 2025.02  
  - course: BS in Mechanical Engineering
    institution: Chung-Ang University
    year: 2022.02
email: "dhkim9669@gmail.com"
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
interests:
- Ca-ion Batteries

role: 
social:
- icon: envelope
  icon_pack: fas
  link: mailto:dhkim9669@gmail.com
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: Daehyun Kim (김대현)
user_groups:
- PhD Students
---


