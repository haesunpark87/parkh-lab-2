---
education:
  courses:
  - course: BS in Integrative Engineering
    institution: Chung-Ang University
    year: On-going
email: ""
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
role: 
social:

interests:
- Data-Driven Materials Discovery

social:
- icon: envelope
  icon_pack: fas
  link: mailto:yooonwoo0303@gmail.com
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: Wonwoo Yoon (윤원우)
user_groups:
- UnderGrad Students
---

---


