---
education:
  courses:
  - course: MS/PhD in Integrative Engineering
    institution: Chung-Ang University
    year: 2025~  
  - course: BS in Mechanical Engineering
    institution: Chung-Ang University
    year: 2024
email: ""
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
interests:
- Hydrogen Evolution Reaction

role: 
social:
- icon: envelope
  icon_pack: fas
  link: mailto:yac1109@naver.com
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: HyoungJoon Jeon (전형준)
user_groups:
- MS Students
---


