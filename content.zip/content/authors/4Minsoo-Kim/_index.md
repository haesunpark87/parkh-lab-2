---
education:
  courses:
  - course: BS in Integrative Engineering
    institution: Chung-Ang University
    year: On-going
email: ""
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
role: 
social:

interests:
- Solid-state Batteries


#- icon: envelope
#  icon_pack: fas
#  link: mailto:parkh@cau.ac.kr
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: Minsoo Kim (김민수)
user_groups:
- Alumni
---
Current Position: TBD

