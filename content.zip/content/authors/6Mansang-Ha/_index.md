---
education:
  courses:
  - course: MS in Integrative Engineering
    institution: Chung-Ang University
    year: 2024~  
  - course: BS, Department of Packaging
    institution: Yonsei University
    year: 2024
email: ""
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
interests:
- All-Solid-State Batteries

role: 
social:
- icon: envelope
  icon_pack: fas
  link: mailto:mansang1221@cau.ac.kr
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: Mansang Ha (하만상)
user_groups:
- MS Students
---


