---
education:
  courses:
  - course: BS in Chemical Engineering
    institution: Chung-Ang University
    year: On-going
email: ""
highlight_name: True
interests:

organizations:
- name: Chung-Ang University
  url: ""
role: 
social:

interests:
- Data-Driven Materials Discovery

social:
- icon: envelope
  icon_pack: fas
  link: mailto:nam6592@gmail.com
#- icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com/citations?user=XKMG__wAAAAJ&hl=kr
#- icon: cv
#  icon_pack: ai
#  link: 'files/CV_Haesun_Park.pdf'
superuser: false
title: Sanghyeon Nam (남상현)
user_groups:
- UnderGrad Students
---

---


