---
# Documentation: https://wowchemy.com/docs/page-builder/
widget: pages
headless: true
weight: 20

title: News
subtitle:

content:
  count: 5
  filters:
    author: ''
    category: ''
    exclude_featured: false
    publication_type: ''
    tag: ''
  offset: 0
  order: desc
  page_type: post
design:
  view: 2
  columns: '2'
---
