---
title: 2024 Korea Battery Symposium 2024년 전지기술심포지엄
date: 2024-08-19
#external_link: http://github.com
image:
  focal_point: 'middle'
---
MIDAS group attended the 2024 Korea Battery Symposium at Seoul!

<!--more-->
