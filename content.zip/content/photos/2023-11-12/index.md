---
title: 2023 Fall KECS meeting 2023년 춘계 전기화학회
date: 2023-11-13
#external_link: http://github.com
image:
  focal_point: 'middle'
---
MIDAS group attended the 2023 Fall KECS meeting at Yeonsu!

<!--more-->
