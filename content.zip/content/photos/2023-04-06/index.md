---
title: 2023 Spring KECS meeting 2023년 춘계 전기화학회
date: 2023-04-06
#external_link: http://github.com
image:
  focal_point: 'middle'
---
MIDAS group attended the 2023 Spring KECS meeting at Jeju!

<!--more-->
