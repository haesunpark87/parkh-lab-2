---
title:  BRL Workshop
date: 2024-10-18
#external_link: http://github.com
image:
  focal_point: 'middle'
---
The 1st year workshop for Basic Research Laboratory at Kent Hotel in Busan


<!--more-->
