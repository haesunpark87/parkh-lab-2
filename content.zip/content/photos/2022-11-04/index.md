---
title: 2022 Fall KECS meeting 춘계 전기 화학회
date: 2022-11-04
#external_link: http://github.com
image:
  focal_point: 'middle'
---

MIDAS group attended the 2022 Fall KECS meeting at Busan!
<!--more-->
