---
title: 2024 Spring KECS meeting 2024년 추계 전기화학회
date: 2024-04-05
#external_link: http://github.com
image:
  focal_point: 'middle'
---
MIDAS group attended the 2024 Spring KECS meeting at Busan!

<!--more-->
