---
title: 2023 Spring Semester Group Dinner 봄 학기 개강 회식
date: 2023-03-16
#external_link: http://github.com
image:
  focal_point: 'middle'
---

<!--more-->
