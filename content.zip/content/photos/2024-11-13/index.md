---
title:  Group Dinner 연구실 회식
date: 2024-11-13
#external_link: http://github.com
image:
  focal_point: 'middle'
---
Group dinner at 노량진


<!--more-->
