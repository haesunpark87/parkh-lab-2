---
title:  Prof. Yang from TU Delf 델프트 공대 양지은 교수 방문
date: 2024-08-19
#external_link: http://github.com
image:
  focal_point: 'middle'
---
Prof. Yang from TU Delft visited our lab to discuss our collaborative work on water electrolysis electrode design.



<!--more-->
