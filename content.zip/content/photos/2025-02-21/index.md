---
title:  Group Dinner 연구실 회식
date: 2025-02-27
#external_link: http://github.com
image:
  focal_point: 'middle'
---
Group dinner at 아마도


<!--more-->
