---
title:  PRiME 2024
date: 2024-10-08
#external_link: http://github.com
image:
  focal_point: 'middle'
---
The MIDAS group attended PRiME 2024 in Honolulu, HI. Daehyun gave a poster presentation. The Siegel group alumni had a reunion dinner with Don.


<!--more-->
